# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: story2-study-overview.spec.js >> Story 2 - Study Overview >> smooth end-to-end journey: complete Story 2 checks in a single browser flow
- Location: tests\story2-study-overview.spec.js:87:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('table tbody tr td a[href^="/studies/"]').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('table tbody tr td a[href^="/studies/"]').first()

```

```yaml
- banner:
  - link "Flight Deck":
    - /url: /
  - navigation:
    - link "Home":
      - /url: /
    - link "Study Portfolio":
      - /url: /portfolio
    - link "Protocol Search":
      - /url: /protocol-search
- main:
  - heading "Study Portfolio Dashboard" [level=1]
  - button "5 Insights"
  - textbox "Search by ID, title, indication..."
  - paragraph: Showing 0 of 0 studies
  - button "Therapeutic Area"
  - combobox: Phase
  - combobox: Study Status
  - combobox: Portfolio
  - combobox: Program
  - combobox: Region
  - button "FPI / LPO"
  - paragraph: Active Studies
  - paragraph: "0"
  - paragraph: recruiting or follow-up
  - paragraph: On Track
  - paragraph: 0.0%
  - paragraph: 0 of 0 active
  - paragraph: At Risk / Off Track
  - paragraph: 0.0%
  - paragraph: 0 of 0 active
  - paragraph: Enrollment vs Target
  - paragraph: 0.0%
  - paragraph: 0 of 0 patients
  - img
  - paragraph: Enrollment vs Plan (To Date)
  - paragraph: 0.0%
  - paragraph: 0 of 0 planned
  - paragraph: Velocity vs Plan
  - paragraph: 0.0%
  - paragraph: avg enrollment speed
  - button "Cards"
  - button "Table"
```

# Test source

```ts
  1   | const { test, expect } = require('../utils/stepTest');
  2   | const { EXPECTED_COLUMNS } = require('../fixtures/dashboardData');
  3   | 
  4   | // Set base URL for this test file only (easy to change)
  5   | const STORY2_BASE_URL = 'https://staying-jump-closest-language.trycloudflare.com/';
  6   | 
  7   | test.describe('Story 2 - Study Overview', () => {
  8   |   test.describe.configure({ mode: 'serial' });
  9   | 
  10  |   let context;
  11  |   let page;
  12  | 
  13  |   const getDashboardUnavailableReason = async () => {
  14  |     let response = await page.goto('/portfolio').catch(() => null);
  15  |     if (!response || response.status() >= 400) {
  16  |       response = await page.goto('/').catch(() => null);
  17  |     }
  18  |     await page.waitForLoadState('networkidle').catch(() => {});
  19  | 
  20  |     const hasDashboard = await page.getByRole('heading', { name: 'Portfolio Dashboard' }).isVisible().catch(() => false);
  21  |     if (hasDashboard) {
  22  |       return null;
  23  |     }
  24  | 
  25  |     const bodyText = await page.locator('body').innerText().catch(() => '');
  26  |     if (response && response.status() >= 400) {
  27  |       return `Dashboard UI unavailable: GET / returned ${response.status()}`;
  28  |     }
  29  | 
  30  |     if (/not found/i.test(bodyText)) {
  31  |       return 'Dashboard UI unavailable: GET / returned Not Found';
  32  |     }
  33  | 
  34  |     return 'Dashboard UI unavailable in current environment';
  35  |   };
  36  | 
  37  |   const openDashboard = async () => {
  38  |     await page.goto('/portfolio').catch(() => page.goto('/'));
  39  |     await page.waitForLoadState('networkidle').catch(() => {});
  40  |     await expect(page.getByRole('heading', { name: 'Portfolio Dashboard' })).toBeVisible();
  41  |   };
  42  | 
  43  |   const goToStudiesList = async () => {
  44  |     await openDashboard();
  45  |     await page.getByRole('link', { name: 'Study Overview' }).first().click();
  46  |     await page.waitForLoadState('networkidle').catch(() => {});
  47  |     await expect(page).toHaveURL(/\/studies\/?$/);
  48  |     await expect(page.getByRole('heading', { name: /Studies/i })).toBeVisible();
  49  |   };
  50  | 
  51  |   const openFirstStudyDetailFromDashboard = async () => {
  52  |     await openDashboard();
  53  | 
  54  |     const cardLink = page.locator('a[href^="/studies/"]').first();
  55  |     if ((await cardLink.count()) > 0) {
  56  |       await cardLink.click({ force: true });
  57  |       await page.waitForLoadState('networkidle').catch(() => {});
  58  |       return;
  59  |     }
  60  | 
  61  |     await page.getByRole('button', { name: 'Table' }).first().click().catch(() => {});
  62  |     const tableLink = page.locator('table tbody tr td a[href^="/studies/"]').first();
> 63  |     await expect(tableLink).toBeVisible();
      |                             ^ Error: expect(locator).toBeVisible() failed
  64  |     await tableLink.click({ force: true });
  65  |     await page.waitForLoadState('networkidle').catch(() => {});
  66  |   };
  67  | 
  68  |   const openFirstStudyDetailFromStudiesList = async () => {
  69  |     await goToStudiesList();
  70  |     const firstStudyLink = page.locator('table tbody tr td a[href^="/studies/"]').first();
  71  |     await expect(firstStudyLink).toBeVisible();
  72  |     await firstStudyLink.click({ force: true });
  73  |     await page.waitForLoadState('networkidle').catch(() => {});
  74  |   };
  75  | 
  76  |   test.beforeAll(async ({ browser }) => {
  77  |     context = await browser.newContext({
  78  |       baseURL: STORY2_BASE_URL,
  79  |     });
  80  |     page = await context.newPage();
  81  |   });
  82  | 
  83  |   test.afterAll(async () => {
  84  |     await context.close();
  85  |   });
  86  | 
  87  |   test('smooth end-to-end journey: complete Story 2 checks in a single browser flow', async () => {
  88  |     const unavailableReason = await getDashboardUnavailableReason();
  89  |     const forceRun = process.env.FORCE_STORY2_RUN === '1';
  90  |     test.skip(!forceRun && !!unavailableReason, unavailableReason);
  91  | 
  92  |     // 1) Navigation from dashboard into a study detail page
  93  |     await openFirstStudyDetailFromDashboard();
  94  |     await expect(page).toHaveURL(/\/studies\/ST-\d{4}-\d{3}/i);
  95  |     await expect(page.getByRole('link', { name: /Back to Studies|Back to Study Portfolio/i })).toBeVisible();
  96  |     await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  97  | 
  98  |     // 2) Navigate back to studies list and validate table + required columns
  99  |     await page.getByRole('link', { name: /Back to Studies|Back to Study Portfolio/i }).click();
  100 |     await page.waitForLoadState('networkidle').catch(() => {});
  101 |     await expect(page).toHaveURL(/\/(studies\/?|portfolio\/?)/i);
  102 | 
  103 |     const studiesHeading = page.getByRole('heading', { name: /Studies/i }).first();
  104 |     const dashboardHeading = page.getByRole('heading', { name: /Study Portfolio Dashboard/i }).first();
  105 |     if ((await studiesHeading.count()) > 0) {
  106 |       await expect(studiesHeading).toBeVisible();
  107 |     } else {
  108 |       await expect(dashboardHeading).toBeVisible();
  109 |     }
  110 | 
  111 |     await page.getByRole('button', { name: 'Table' }).first().click().catch(() => {});
  112 | 
  113 |     const table = page.locator('table, [role="table"]').first();
  114 |     await expect(table).toBeVisible();
  115 | 
  116 |     const headers = await page.locator('table thead th').allInnerTexts();
  117 |     const normalizedHeaders = headers.map((header) => header.replace(/\s+/g, ' ').trim().toLowerCase());
  118 | 
  119 |     for (const expectedColumn of EXPECTED_COLUMNS) {
  120 |       expect(normalizedHeaders).toContain(expectedColumn.toLowerCase());
  121 |       await expect(
  122 |         page
  123 |           .getByRole('columnheader', {
  124 |             name: new RegExp(`^${expectedColumn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i'),
  125 |           })
  126 |           .first(),
  127 |       ).toBeVisible();
  128 |     }
  129 | 
  130 |     // 3) Open a study detail from studies list for deep validations
  131 |     const firstStudyLink = page.locator('table tbody tr td a[href^="/studies/"]').first();
  132 |     if ((await firstStudyLink.count()) > 0) {
  133 |       await expect(firstStudyLink).toBeVisible();
  134 |       await firstStudyLink.click({ force: true });
  135 |     } else {
  136 |       const firstCardLink = page.locator('a[href^="/studies/"]').first();
  137 |       await expect(firstCardLink).toBeVisible();
  138 |       await firstCardLink.click({ force: true });
  139 |     }
  140 |     await page.waitForLoadState('networkidle').catch(() => {});
  141 | 
  142 |     // 4) Header section + study attributes
  143 |     await expect(page.getByRole('heading', { level: 1 }).first()).toBeVisible();
  144 | 
  145 |     const headerBadges = ['Ph I', 'Ph II', 'Recruiting', 'High Priority', 'Off Track', 'On Track', 'At Risk'];
  146 |     const anyBadgeVisible =
  147 |       (await Promise.all(
  148 |         headerBadges.map((label) => page.getByText(new RegExp(`^${label}$`, 'i')).first().isVisible().catch(() => false)),
  149 |       )).some(Boolean);
  150 |     expect(anyBadgeVisible).toBeTruthy();
  151 | 
  152 |     const metadataLabels = [
  153 |       'Asset',
  154 |       'Asset Lead',
  155 |       'FSO Model',
  156 |       'Study Sponsor',
  157 |       'Designation',
  158 |       'Target Enrollment',
  159 |       'Planned FPI',
  160 |       'Actual FPI',
  161 |       'Planned LPI',
  162 |       'Forecast LPI',
  163 |     ];
```